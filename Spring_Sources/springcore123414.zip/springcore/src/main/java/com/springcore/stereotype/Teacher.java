package com.springcore.stereotype;

public class Teacher {

}
